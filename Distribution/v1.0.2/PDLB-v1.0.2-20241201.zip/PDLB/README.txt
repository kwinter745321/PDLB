Version 1.0.0

Instructions

1. Unzip this kit into a application area folder. Although it can be put anywhere.
The application will want to have a workspace/project for you to store "src" project files.

NOTE: Currently you must manually add this application to your SYSTEM PATH.

2. Updating Windows Desktop System env variables:

click Windows logo in Task Bar.
click Settings (icon looks like a gear).
Look for "Find a Setting" in the top left, and enter:  env
Select "Edit the system environment variable"  this should display System Properties dialog.
Near bottom, click "Environment Variables".
Select "Path" in User variables, and click "Edit" button.
Click "New" and on the line that just opened, type (or paste) location for "bin"
for example:  I entered:  C:\Users\kevin\Documents\Kits\PDLB\bin

If you cannot do this then you need to invoke the program from a DOS prompt.

3.  Double click the file "pdlb.exe"
When the application begins, it will prompt for the workspace folder name.
Use the dialog to create a New Folder name (WorkspacePDLB).  
Select that folder name and click the 'Select Folder' button.

Or, select the folder for the workspace. (Note: Project folders are saved within it.)


PDLB\
  	bin\
		pdlb.exe
                code.txt
		workspace.pdlb (will be created on startup)
		images\
			image files needed by exe
	examples\
		holds examples. Create a project called Examples in your workspace.  Then copy these files to it.

	Addon\


For the add-on application, there are two entry fields in the Global Properties. 
<Addon> 			into this field put a proper path and executable.  For example, C:\MMedit5\MMEdit.exe
<AddonTarget>  			This is a parameter for the add-on.  

You can enter one of three choices: NONE BAS SRC
Nothing is passed to add-on, if you entered None
This will pass the current file output, if you entered BAS
This will pass the current file source input, if you entered SRC

3. Find the Menu bar and click "New Project".
Use the dialog to create a New Folder name (for example: "PinkProject").  
Select that folder name and click the 'Select Folder' button.

Note: It is important to use "New Project" as it creates both the project folder
and images sub folder.  It also copies cross.jpg to the images folder.  These can just
be manually copied to a new project folder (if necessary.)

4. Use the Menu again and click "Save as" and enter a filename (for example: "Pink.src".)
Note there is no "New File" menu item.

5. Drag a "Control" to the canvas.  Edit its properties. Click the "Update" button (if it goes pink).

Features

MOVE
1. Left-click to select a Control to move it (a dashed border "lasso" surrounds it.)  Move likes the control to be "updated" first.
   The lasso currently only allows one control to be moved at a time.

RESIZE
2. Right-click to move, resize or delete a control. Re-size is quirky. 
It places a tiny yellow square at the bottom right edge of the Control.
Left-Click (and hold) the mouse over the yellow box and slowly drag the mouse to the right (and release.)
The Control will resize. Some Controls cannot use the Resize feature (the resize will be disabled.)
To stop RESIZE, you use the mouse to "release resize" or press the <ESCAPE> key.

SNAP GUIDE
Note:  You will only want to "Enable" it briefly. As all controls will snap to it that are placed or touched.
3. Say you want to place captions vertically with their left edge at column 50.
   * Click in the Properties pane on a Tab labeled "Snap Guide".
   * Then type 50 in the SnapX entry box.
   * Click "Enable".  A yellow-snap guide will appear.

Now, place controls anywhere on the canvas... they will 'snap' their left-edge to the guide.
You can place more Controls and even edit their properties.
When ready, go back to the Snap property and "Disable" the snap guide.

GENERATE
a) Build Controls will write a text "BAS" file containing PicoMite command codes.
b) Build Controls & Code will do the same but include some example code for any Control. 





Release 1.0.0 2024-09-18

Initial kit build